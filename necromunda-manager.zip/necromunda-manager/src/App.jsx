function App() {
  return (
    <div className="min-h-screen surface-ground">
      {<Route path="/" element={<Home />} />}
    </div>
  );
}
